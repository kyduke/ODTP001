enyo.kind({
	name: "MyApp.MainView",
	kind: "FittableColumns",
	classes: "enyo-fit",
	controller: ".app.controllers.messageController",
	bindings: [{
		from: ".controller.title",
		to: ".titleData",
		transform: "moveNextPanel"
	}],
	components: [
		{kind: "enyo.Spotlight"},
		{name: "panels", kind: "moon.Panels", fit: true, arrangerKind: "moon.LeanForwardArranger", components: [
			{kind: "MyApp.EventView"},
			{kind: "MyApp.FirstView"},
			{kind: "MyApp.SecondView", joinToPrev: true, ontap: "tapHandler"},
			{name: "album", kind: "MyApp.ThirdView"}
		]}
	],
	
	tapHandler: function(inSender, inEvent) {
		this.$.album.setTitle(inEvent.originator.content);
		this.$.panels.next();
	},
	
	moveNextPanel: function(title) {
		if (title == undefined){
			return;
		}
		return;
		console.log("moveNext");
		this.$.panels.next();
	}
});
