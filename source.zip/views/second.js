enyo.kind({
	name: "MyApp.SecondView",
	kind: "moon.Panel",
	classes: "moon main-view",
	controller: ".app.controllers.messageController",
	titleBelow: "Second",
	bindings: [{
		from: ".controller.message",
		to: ".title"
	}],
	components: [
		{kind: "moon.Scroller", style: "height: 300px;", components: [
			{kind: "moon.Item", content: "Album 2-1", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-2", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-3", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-4", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-5", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-6", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-7", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-8", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-9", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-10", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-11", ontap: "tapHandler"},
			{kind: "moon.Item", content: "Album 2-12", ontap: "tapHandler"}
		]}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	],
	
	tapHandler: function(inSender, inEvent) {
		console.log(inSender);
		console.log(inSender.getContent());
		this.controller.set("title", inSender.getContent());
		console.log(this.controller.title);
	}
});
