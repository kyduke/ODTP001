enyo.kind({
	name: "MyApp.EventView",
	kind: "moon.Panel",
	title: "Event Handling",
	components: [
		{kind: "FittableColumns", components: [
			{components: [
				{kind: "moon.Button", content: "Button 1", ontap: "tapHandler", onSpotlightDown: "spotDown"},
				{kind: "moon.Button", content: "Button 2", ontap: "tapHandler", onSpotlightLeft: "stopSpotlight"},
			]},
			{name: "log", kind: "LogArea"}
		]}
	],
	
	tapHandler: function(inSender, inEvent) {
		this.$.log.addContent("tap ");
	},
	
	spotDown: function(inSender, inEvent) {
		this.$.log.addContent("spotlight(down) ");
	},
	
	stopSpotlight: function(inSender, inEvent) {
		this.$.log.addContent("spotlight(left) ");
		return true;
	}
});

enyo.kind({
	name: "LogArea",
	fit: true,
	style: "height: 200px; width: 300px; border: 1px solid black;"
});
