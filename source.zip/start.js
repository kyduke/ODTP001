enyo.ready(function () {
	new MyApp.Application({name: "app"});
});
