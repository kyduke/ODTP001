enyo.kind({
	name: "MyApp.SecondPanel",
	kind: "moon.Panel",
	classes: "moon main-view",
	title: "Track Name",
	titleBelow: "Artist Name",
	components: [
		{kind: "FittableColumns", fit: true, components: [
			{classes: "moon-6h", components: [
				{kind: "enyo.Image", src: "http://placehold.it/450x350"},
				{
					kind: "moon.Table",
					fit: true,
					components: [
						{components: [
							{content: "Released"},
							{name: "released"}
						]},
						{name: "genreRow", components: [
							{content: "Genre"},
							{name: "genre"}
						]},
					]
				}
			]},
			{kind: "moon.Scroller", fit: true, spotlight: false, components: [
				{kind: "moon.Divider", content: "Lyrics"},
				{
					allowHtml: true,
					content:  "Can't see the lights or the blue ora" +
							  "nge signs<br />Can't see the road or" +
							  "the long white lines<br />Feeling th" +
							  "e ground through the pedals on the f" +
							  "loor<br />Felling death pounding at " +
							  "the door<br /><br />Windows all open" +
							  ", chaos in my hair<br />Driving me r" +
							  "ound and leaving me there<br />Cover" +
							  " my eyes and we'll die driving blind" +
							  "<br />Cover my trail and we'll leave" +
							  " this life behind<br /><br />Drive b" +
							  "lind<br /><br />All at onec, too mus" +
							  "h light<br />Captured and frozen, he" +
							  "ar no sound<br />Bright flashes pene" +
							  "trate<br />Glowing, flowing, lifting" +
							  " off the ground"
				}
			]},
			{
				kind: "moon.Scroller",
				classes: "moon-3h",
				fit: true,
				defaultKind: "moon.Item",
				components: [
					{kind: "moon.Divider", content: "more"},
					{content: "Artist"},
					{content: "Album"},
					{content: "Similar Track"},
					{content: "Related Videos"}
				]
			}
		]}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	]
});
