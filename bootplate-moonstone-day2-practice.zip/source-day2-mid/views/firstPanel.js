enyo.kind({
	name: "MyApp.FirstPanel",
	kind: "moon.Panel",
	classes: "moon main-view",
	controller: ".app.controllers.album",
	title: "",
	titleBelow: "",
	tracks: null,
	bindings: [
		{from: ".controller.title", to: ".title"},
		{from: ".controller.titleBelow", to: ".titleBelow"},
		{from: ".controller.tracks", to: ".tracks"}
	],
	components: [
		{kind: "moon.Divider", content: "Track list"},
		{
			name: "trackList",
			kind: "moon.List",
			fit: true,
			onSetupItem: "setupItem",
			components: [
				{name: "trackEntry"}
			]
		}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	],
	
	setupItem: function(inSender, inEvent) {
		var idx = inEvent.index;
		var tracks = this.get("tracks");
		this.$.trackEntry.set("content", tracks[idx].title);
	},
	
	tracksChanged: function(prev, value) {
		var tracks = this.get("tracks");
		if (tracks) {
			this.$.trackList.set("count", tracks.length);
			this.$.trackList.refresh();
		}
	}
});
