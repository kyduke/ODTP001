enyo.kind({
	name: "MyApp.AlbumModel",
	kind: "enyo.Model",
	attributes: {
		title: "Album 1",
		titleBelow: "Artist 1",
		tracks: [
			{title: "Track 1", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 2", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 3", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 4", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 5", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 6", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 7", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 8", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 9", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 10", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 11", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"},
			{title: "Track 12", titleBelow: "Artist 1",released: "28 May 2013", genre: "Dance"}
		]
	}
});