enyo.kind({
	name: "MyApp.Album",
	kind: "enyo.ModelController"
});
