enyo.kind({
	name: "MyApp.Application",
	kind: "enyo.Application",
	controllers: [
		{name: "album", kind: "MyApp.Album"}
	],
	view: "MyApp.MainView",
	
	create: function() {
		this.inherited(arguments);
		this.controllers.album.set("model", new MyApp.AlbumModel());
	}
});