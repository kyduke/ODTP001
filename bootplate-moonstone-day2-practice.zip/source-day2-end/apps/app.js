enyo.kind({
	name: "MyApp.Application",
	kind: "enyo.Application",
	controllers: [
		{name: "albums", kind: "MyApp.Albums", onModelsAdded: "modelsAdded"},
		{name: "selectedAlbum", kind: "MyApp.SelectedAlbum"}
	],
	view: "MyApp.MainView",
	
	modelsAdded: function(inSender, inEvent) {
		this.controllers.selectedAlbum.set("model", this.controllers.albums.at(0));
	}
});