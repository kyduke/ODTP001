enyo.kind({
	name: "MyApp.Albums",
	kind: "enyo.Collection",
	url: "assets/albums.json"
});