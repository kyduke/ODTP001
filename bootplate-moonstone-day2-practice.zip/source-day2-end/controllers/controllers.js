enyo.kind({
	name: "MyApp.SelectedAlbum",
	kind: "enyo.ModelController"
});
