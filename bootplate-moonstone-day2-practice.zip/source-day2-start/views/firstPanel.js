enyo.kind({
	name: "MyApp.FirstPanel",
	kind: "moon.Panel",
	classes: "moon main-view",
	controller: ".app.controllers.albumController",
	bindings: [{
		from: ".controller.title",
		to: ".title"
	}],
	components: [
		{
			kind: "moon.Scroller",
			fit: true,
			defaultKind: "moon.Item",
			components: [
				{kind: "moon.Divider", content: "Track list"},
				{content: "Track 1-1"},
				{content: "Track 1-2"},
				{content: "Track 1-3"},
				{content: "Track 1-4"},
				{content: "Track 1-5"},
				{content: "Track 1-6"},
				{content: "Track 1-7"},
				{content: "Track 1-8"},
				{content: "Track 1-9"},
				{content: "Track 1-10"},
				{content: "Track 1-11"},
				{content: "Track 1-12"}
			]
		}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	]
});
