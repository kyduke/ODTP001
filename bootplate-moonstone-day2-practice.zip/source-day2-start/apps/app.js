enyo.kind({
	name: "MyApp.Application",
	kind: "enyo.Application",
	controllers: [{
		name: "albumController",
		kind: "enyo.Controller",
		title: "Album Name"
	}],
	view: "MyApp.MainView"
});