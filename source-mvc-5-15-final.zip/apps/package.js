enyo.depends(
	"app.js"
);
