/*
enyo.kind({
	name: "MyApp.Application",
	kind: "enyo.Application",
	controllers: [{
		name: "messageController",
		kind: "enyo.Controller",
		message: $L("Hello World")
	}],
	view: "MyApp.MainView"
});
*/

//step 10- mvc
enyo.kind({
	name: "MyApp.Application",
	kind: "enyo.Application",
	view: "MyApp.MainView",
	controllers: [
		{
			name: "albums",
			kind: "enyo.Collection"
		},
		{
			name: "selectedModel",
			kind: "enyo.ModelController"
		}
	]
});

