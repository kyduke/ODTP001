/*
enyo.kind({
	name: "MyApp.FirstView",
	kind: "moon.Panel",
	classes: "moon main-view",
	controller: ".app.controllers.messageController",
	titleBelow: "First",
	bindings: [{
		from: ".controller.message",
		to: ".title"
	}],
	components: [
		{kind: "moon.Item", content: "1 Your content here"},
		{kind: "moon.Item", spotlightPosition: "right", content: "1 Your content here"}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	]
});
*/

//step 10- mvc
enyo.kind({
	name: "MyApp.FirstView",
	kind: "moon.Panel",
	classes: "moon main-view",
	title: "First Panel",
	titleBelow: "First",
	components: [
		{kind: "moon.Item", content: "1 Your content here"},
		{kind: "moon.Item", spotlightPosition: "right", content: "1 Your content here"}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	]
});
