enyo.depends(
	"main.js",
	"first.js",
	"second.js",
	"third.js",
	"eventPanel.js"
);
