/*
enyo.kind({
	name: "MyApp.ThirdView",
	kind: "moon.Panel",
	classes: "moon main-view",
	controller: ".app.controllers.messageController",
	title: "Album",
	titleBelow: "Third",
	bindings: [{
		from: ".controller.title",
		to: ".title"
	}],
	components: [
		{
			kind: "FittableColumns",
			components: [
				{kind: "enyo.Image", src: "http://placehold.it/200x200", style: "height: 200px; width: 200px;"},
				{kind: "moon.Scroller", fit: true, components: [
					{kind: "moon.Divider", content: "Lylics"},
					{
						classes: "moon-10h",
						components: [
							{
								allowHtml: true,
								content: "Can't see the lights or the blue ora" +
										 "nge signs<br />Can't see the road or" +
										 "the long white lines<br />Feeling th" +
										 "e ground through the pedals on the f" +
										 "loor<br />Felling death pounding at " +
										 "the door<br /><br />Windows all open" +
										 ", chaos in my hair<br />Driving me r" +
										 "ound and leaving me there<br />Cover" +
										 " my eyes and we'll die driving blind" +
										 "<br />Cover my trail and we'll leave" +
										 " this life behind<br /><br />Drive b" +
										 "lind<br /><br />All at onec, too mus" +
										 "h light<br />Captured and frozen, he" +
										 "ar no sound<br />Bright flashes pene" +
										 "trate<br />Glowing, flowing, lifting" +
										 " off the ground"
							}
						]
					}
				]},
				{}
			]
		}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	]
});
*/

//step 10- mvc
enyo.kind({
	name: "MyApp.ThirdView",
	kind: "moon.Panel",
	classes: "moon main-view",
	title: "Album",
	titleBelow: "Third",
	components: [
		{
			kind: "FittableColumns",
			components: [
				{kind: "enyo.Image", src: "http://placehold.it/200x200", style: "height: 200px; width: 200px;"},
				{kind: "moon.Scroller", fit: true, components: [
					{kind: "moon.Divider", content: "Lylics"},
					{
						classes: "moon-10h",
						components: [
							{
								allowHtml: true,
								content: "Can't see the lights or the blue ora" +
										 "nge signs<br />Can't see the road or" +
										 "the long white lines<br />Feeling th" +
										 "e ground through the pedals on the f" +
										 "loor<br />Felling death pounding at " +
										 "the door<br /><br />Windows all open" +
										 ", chaos in my hair<br />Driving me r" +
										 "ound and leaving me there<br />Cover" +
										 " my eyes and we'll die driving blind" +
										 "<br />Cover my trail and we'll leave" +
										 " this life behind<br /><br />Drive b" +
										 "lind<br /><br />All at onec, too mus" +
										 "h light<br />Captured and frozen, he" +
										 "ar no sound<br />Bright flashes pene" +
										 "trate<br />Glowing, flowing, lifting" +
										 " off the ground"
							}
						]
					}
				]},
				{}
			]
		}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	]
});
