/*
enyo.kind({
	name: "MyApp.MainView",
	kind: "FittableColumns",
	classes: "enyo-fit",
	controller: ".app.controllers.messageController",
	bindings: [{
		from: ".controller.title",
		to: ".titleData",
		transform: "moveNextPanel"
	}],
	components: [
		{kind: "enyo.Spotlight"},
		{name: "panels", kind: "moon.Panels", fit: true, arrangerKind: "moon.LeanForwardArranger", components: [
			{kind: "MyApp.EventView"},
			{kind: "MyApp.FirstView"},
			{kind: "MyApp.SecondView", joinToPrev: true, ontap: "tapHandler"},
			{name: "album", kind: "MyApp.ThirdView"}
		]}
	],
	
	//form handler
	tapHandler: function(inSender, inEvent) {
		this.$.album.setTitle(inEvent.originator.content);
		return;
		this.$.panels.next();
	},
	
	//from controller
	moveNextPanel: function(title) {
		if (title == undefined){
			return;
		}
		//return;
		console.log("moveNext");
		this.$.panels.next();
	}
});
*/

//step 10- mvc
enyo.kind({
	name: "MyApp.MainView",
	kind: "FittableColumns",
	classes: "enyo-fit",
	trackTitle: "",
	controller: ".app.controllers.selectedModel",
	bindings: [
		{
			from: ".controller.trackTitle",
			to: ".trackTitle"
		}
	],
	components: [
		{kind: "enyo.Spotlight"},
		{name: "panels", kind: "moon.Panels", fit: true, arrangerKind: "moon.LeanForwardArranger", components: [
			{kind: "MyApp.EventView"},
			{kind: "MyApp.FirstView"},
			{kind: "MyApp.SecondView", joinToPrev: true, ontap: "tapHandler"},
			{name: "album", kind: "MyApp.ThirdView"}
		]}
	],
	
	tapHandler: function(inSender, inEvent) {
		this.$.album.setTitle(this.trackTitle);
		this.$.panels.next();
	}
});