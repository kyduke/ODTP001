/*
enyo.kind({
	name: "MyApp.SecondView",
	kind: "moon.Panel",
	classes: "moon main-view",
	controller: ".app.controllers.messageController",
	titleBelow: "Second",
	bindings: [{
		from: ".controller.message",
		to: ".title"
	}],
	components: [
		{kind: "moon.Scroller", style: "height: 300px;", ontap: "tapHandler", components: [
			{kind: "moon.Item", content: "Album 2-1"},
			{kind: "moon.Item", content: "Album 2-2"},
			{kind: "moon.Item", content: "Album 2-3"},
			{kind: "moon.Item", content: "Album 2-4"},
			{kind: "moon.Item", content: "Album 2-5"},
			{kind: "moon.Item", content: "Album 2-6"},
			{kind: "moon.Item", content: "Album 2-7"},
			{kind: "moon.Item", content: "Album 2-8"},
			{kind: "moon.Item", content: "Album 2-9"},
			{kind: "moon.Item", content: "Album 2-10"},
			{kind: "moon.Item", content: "Album 2-11"},
			{kind: "moon.Item", content: "Album 2-12"}
		]}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	],
	
	tapHandler: function(inSender, inEvent) {
		console.log(inSender);
		console.log(inSender.getContent());
		this.controller.set("title", inSender.getContent());
		console.log(this.controller.title);
	}
});
*/

//step 10- mvc
enyo.kind({
	name: "MyApp.SecondView",
	kind: "moon.Panel",
	classes: "moon main-view",
	controller: ".app.controllers.selectedModel",
	title: "",
	titleBelow: "Second",
	trackTitle: "",
	bindings: [
		{
			from: ".controller.title",
			to: ".title"
		},
		{
			from: ".controller.trackTitle",
			to: ".trackTitle",
			oneWay: false
		}
	],
	trackTitleChanged: function() {
		this.log();
	},
	components: [
		{kind: "FittableColumns", fit: true, components: [
			{classes: "moon-4h", style: "height: 100px; border: 1px solid red;"},
			{
				kind: "FittableRows",
				fit: true,
				components: [
					{
						kind: "moon.Scroller",
						fit: true,
						components: [
							{kind: "moon.Divider", content: "Track list"},
							{name: "tracks", kind: "Sample.tracks", ontap: "tapHandler"}
						]
					}
				]
			},
		]}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	],
	tapHandler: function(inSender, inEvent) {
		this.set("trackTitle", inEvent.originator.content);
	}
});

enyo.kind({
	name: "Sample.tracks",
	controller: ".app.controllers.albums",
	onSetupItem: "setupItem",
	bindings: [
		{
			from: ".controller.length",
			to: ".$.tracks.count"
		}
	],
	components: [
		{
			name: "tracks",
			kind: "Repeater",
			onSetupItem:"setupItem",
			components: [
				{
					name: "item",
					components: [
						{name: "track", kind: "moon.Item", content: "Track 8"}
					]
				}
			]
		}
	],
	setupItem: function(inSender, inEvent) {
		var item = inEvent.item;
		var index = inEvent.index;
		var track = this.controller.at(0).get("tracks")[index].name;
		item.$.track.setContent(track);
	}
});

