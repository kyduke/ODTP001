enyo.depends(
	"main.js",
	"firstPanel.js",
	"secondPanel.js",
	"eventsPanel.js"
);
