enyo.kind({
	name: "EventsPanel",
	kind: "moon.Panel",
	title: "Events Sandbox!",
	handlers: {
	},
	components: [
		{kind: "FittableColumns", components: [
			{components: [
				{name: "myButton", kind: "moon.SpecialButton", content: "Tap me!",
					ontap: "handleTap"//,
					//onSpotlightDown: "spotDown"
				},
				{name: "myButton2", kind: "moon.Button", content: "Button 2",
					onSpotlightLeft: "stopSpotLeft"
				}
			]},
			{name: "logArea", kind: "LoggingArea", fit: true}
		]}
	],
	handleTap: function(inSender, inEvent) {
		this.log("Owner caught tap event")
		this.$.logArea.setContent(this.$.logArea.getContent() + " Button was pressed!");
		return true
	},
	spotDown: function(inSender, inEvent) {
		this.$.logArea.setContent(this.$.logArea.getContent() + " Spotlight down!");	
	},
	stopSpotLeft: function(inSender, inEvent) {
		this.$.logArea.setContent(this.$.logArea.getContent() + " Spotlight left!");
		return true;
	}
});

enyo.kind({
	name: "moon.SpecialButton",
	kind: "moon.Button",
	handlers: {
		ontap: "handleMyTap"
	},
	handleMyTap: function(inSender, inEvent) {
		this.log("SpecialButton tap handler");
		return true;
	}
})

enyo.kind({
	name: "LoggingArea",
	style: "height: 200px; margin: 20px; border: 1px solid #3a4d5a;"
});