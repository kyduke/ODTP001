enyo.kind({
	name: "MyApp.AppTest",
	kind: "FittableColumns",
	classes: "enyo-fit",
	handlers: {
		onSelectedTrackChanged: "selectedTrackChanged"
	},
	components: [
		{kind: "enyo.Spotlight"},
		{name: "panels", kind: "moon.Panels", fit: true, arrangerKind: "moon.LeanForwardArranger", components: [
			//{kind: "EventsPanel"},
			{name: "panel1", kind: "MyApp.FirstPanel"},
			{name: "panel2", kind: "MyApp.SecondPanel"}
		]}
	],
	selectedTrackChanged: function (sender, event) {
		var track = event.track;
		this.$.panel2.set("track", track);
		this.$.panels.setIndex(1);
		return true;
	}
});