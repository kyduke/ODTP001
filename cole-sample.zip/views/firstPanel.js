enyo.kind({
	name: "MyApp.FirstPanel",
	kind: "moon.Panel",
	classes: "moon main-view",
	title: "",
	titleBelow: "",
	tracks: null,
	controller: ".app.controllers.selectedAlbum",
	events: {
		onSelectedTrackChanged: ""
	},
	bindings: [{
		from: ".controller.title",
		to: ".title"
	}, {
		from: ".controller.titleBelow",
		to: ".titleBelow"
	}, {
		from: ".controller.tracks",
		to: ".tracks"
	}],
	tracksChanged: function () {
		var tracks = this.get("tracks");
		if (tracks) {
			this.$.trackList.set("count", tracks.length);
			this.$.trackList.refresh();
		}
	},
	setupItem: function (sender, event) {
		var idx = event.index;
		var tracks = this.get("tracks");
		this.$.trackEntry.set("content", tracks[idx].title);
	},
	trackTapped: function (sender, event) {
		var tracks = this.get("tracks");
		var idx = event.index;
		var track = tracks[idx];
		this.doSelectedTrackChanged({track: track});
		return true;
	},
	components: [
		{kind: "FittableColumns", fit: true, components: [
			{classes: "moon-4h", style: "height: 100px; border: 1px solid red;"},
			{kind: "FittableRows", fit: true, components: [
				{
					name: "trackList",
					kind: "moon.List",
					fit: true,
					onSetupItem: "setupItem",
					components: [{
						name: "trackEntry",
						kind: "moon.Item",
						ontap: "trackTapped"
					}]
				}
				/*{name: "scroller", kind: "moon.Scroller", fit: true, components: [
					{kind: "moon.Divider", content: "Track list"}
					{kind: "moon.Item", content: "Track 1"},
					{kind: "moon.Item", content: "Track 2"},
					{kind: "moon.Item", content: "Track 3"},
					{kind: "moon.Item", content: "Track 4"},
					{kind: "moon.Item", content: "Track 5"},
					{kind: "moon.Item", content: "Track 6"},
					{kind: "moon.Item", content: "Track 7"},
					{kind: "moon.Item", content: "Track 8"}
				]}*/
			]},
		]}
	],
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	]
});
