enyo.kind({
	name: "MyApp.SecondPanel",
	kind: "moon.Panel",
	classes: "moon main-view",
	title: "Track Name",
	titleBelow: "Artist Name",
	track: null,
	trackChanged: function () {
		var track = this.get("track");
		if (track) {
			this.set("title", track.title);
			this.set("titleBelow", track.titleBelow);
		}
	},
	headerComponents: [
		{kind: "moon.IconButton", src: "assets/icon-like.png"}
	],
	components: [
		{kind: "FittableColumns", fit: true, components: [
			{components: [
				{classes: "moon-4h", style: "border: 1px solid green; height:100px;"},
				{content: "Released"},
				{content: "Genre"}
			]},
			{kind: "FittableRows", fit: true, components: [
				{kind: "moon.Scroller", fit: true, components: [
					{kind: "moon.Divider", content: "Lyrics"},
					{allowHtml: true, content: 	 "Can't see the lights or the blue ora" +
						                         "nge signs<br />Can't see the road or" +
						                         "the long white lines<br />Feeling th" +
						                         "e ground through the pedals on the f" +
						                         "loor<br />Felling death pounding at " +
						                         "the door<br /><br />Windows all open" +
						                         ", chaos in my hair<br />Driving me r" +
						                         "ound and leaving me there<br />Cover" +
						                         " my eyes and we'll die driving blind" +
						                         "<br />Cover my trail and we'll leave" +
						                         " this life behind<br /><br />Drive b" +
						                         "lind<br /><br />All at onec, too mus" +
						                         "h light<br />Captured and frozen, he" +
						                         "ar no sound<br />Bright flashes pene" +
						                         "trate<br />Glowing, flowing, lifting" +
						                         " off the ground"
	            	}
	            ]},
	        ]},
			{classes: "moon-3h", kind: "FittableRows", components: [
				{kind: "moon.Scroller", fit: true, defaultKind: "moon.Item", components: [
					{kind: "moon.Divider", content: "More"},
					{content: "Artist"},
					{content: "Album"},
					{content: "Similar Tracks"},
					{content: "Related Videos"}
				]}
			]}
		]}
	]
});
