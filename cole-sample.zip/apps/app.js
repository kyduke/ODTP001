enyo.kind({
	name: "MyApp.Application",
	kind: "enyo.Application",
	view: "MyApp.AppTest",
	controllers: [{
		name: "albums",
		kind: "enyo.Collection"
	}, {
		name: "selectedAlbum",
		kind: "enyo.ModelController"
	}]
});
