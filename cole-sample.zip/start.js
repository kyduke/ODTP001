enyo.ready(function () {
	app = new MyApp.Application({name: "app"});

	app.controllers.albums.add([
	{
		"title": "Super Awesome Album",
		"titleBelow": "Another Awesome Title",
		"tracks": [
			{
				"title": "track1",
				"titleBelow": "Someone"
			},
			{
				"title": "track2",
				"titleBelow": "Someone"
			}
		]
	},	{
		"name": "album2",
		"tracks": [
			{
				"name": "track1"
			},
			{
				"name": "track2"
			}
		]
	}, 	{
		"name": "album3",
		"tracks": [
			{
				"name": "track1"
			},
			{
				"name": "track2"
			}
		]
	}
	]);

	app.controllers.selectedAlbum.set("model",
		app.controllers.albums.at(0));

	/*enyo.kind({
		name: "Sample.View",
		kind: "enyo.View",

		bindings: [{
			from: ".$.view1.content",
			to: ".$.view2.value",
			oneWay: false
		}],

		components: [{
			name: "view1",
			content: "hi"
		}, {
			name: "view2",
			kind: "enyo.Input"
		}]
	});

	(view = new Sample.View()).renderInto(document.body);*/
/*
	enyo.kind({
		name: "Sample.Controller",
		kind: "enyo.Controller",
		data: "Hi."
	});

	enyo.kind({
		name: "Sample.Application",
		kind: "enyo.Application",
		controllers: [{
			name: "contentController",
			kind: "Sample.Controller",
		}],
		view: "Sample.View"
	});

	enyo.kind({
		name: "Sample.View",
		kind: "enyo.View",
		bindings: [{
			from: ".app.controllers.contentController.data",
			to: ".data"
		}, {
			from: ".data",
			to: ".$.view1.content"
		}, {
			from: ".data",
			to: ".$.view2.content"
		}, {
			from: ".$.view3.value",
			to: ".app.controllers.contentController.data"
		}],
		components: [{
			name: "view1"
		}, {
			name: "view2"
		}, {
			name: "view3",
			kind: "enyo.Input"
		}]
	});

	app = new Sample.Application({name: "app"});*/
/*

	enyo.kind({
		name: "Sample.ContactCollection",
		kind: "enyo.Collection",
		model: "Sample.ContactModel"
	});
*/
/*
	enyo.kind({
		name: "Sample.DetailView",
		kind: "enyo.View",
		style: "padding: 15px;"
	});

	enyo.kind({
		name: "Sample.View",
		kind: "enyo.View",
		controller: ".app.controllers.contact",
		bindings: [{
			from: ".controller.first",
			to: ".$.first.content"
		}, {
			from: ".controller.last",
			to: ".$.last.content"
		}, {
			from: ".controller.age",
			to: ".$.age.content"
		}, {
			from: ".controller.fullName",
			to: ".$.full.content"
		}],
		components: [{
			layoutKind: "enyo.FittableColumnsLayout",
			defaultKind: "Sample.DetailView",
			components: [{
				name: "first"
			}, {
				name: "last"
			}, {
				name: "full"
			}, {
				name: "age"
			}]
		}]
	});

	/*enyo.kind({
		name: "Sample.View",
		kind: "enyo.DataList",
		controller: ".app.controllers.contacts",
		components: [{
			bindFrom: ".first"
		}, {
			bindFrom: ".last"
		}, {
			bindFrom: ".age"
		}]
	});*/
/*
	enyo.kind({
		name: "Sample.ModelController",
		kind: "enyo.ModelController",
		fullName: enyo.computed(function () {
			return this.get("first") + " " + this.get("last");
		}, "first", "last")
	});

	enyo.kind({
		name: "Sample.Application",
		kind: "enyo.Application",
		controllers: [{
			name: "contact",
			kind: "Sample.ModelController"
		}],
		view: "Sample.View"
	});

	enyo.kind({
		name: "Sample.ContactModel",
		kind: "enyo.Model",
		attributes: {
			first: "",
			last: "",
			age: 0
		}
	});


	app = new Sample.Application({name: "app"});

	model = new Sample.ContactModel({
		first: "Cole",
		last: "Davis",
		age: 100000000
	});

	app.controllers.contact.set("model", model);

	/*app.controllers.contacts.add([
	{
		first: "First1",
		last: "Last1",
		age: 1
	},
	{
		first: "First2",
		last: "Last2",
		age: 2
	}, 	
	{
		first: "First3",
		last: "Last3",
		age: 3
	}
	]);*/

	// computed property for full-name
	// binding kind to handle non-empty divs

/**

	enyo.kind({
		name: "Sample.View",
		kind: "enyo.DataList",
		controller: ".app.controllers.contacts",
		components: [
			{bindFrom: ".first"},
			{bindFrom: ".last"},
			{bindFrom: ".age"},
		]
	});
	
	enyo.kind({
		name: "Sample.Application",
		kind: "enyo.Application",
		controllers: [
			{
				name: "contacts",
				kind: "enyo.Collection"
			}
		],
		view: "Sample.View"
	});
	
	app = new Sample.Application({name: "app"});
	
	app.controllers.contacts.add([
		{
			first: "First1",
			last: "Last1",
			age: 1
		},
		{
			first: "First2",
			last: "Last2",
			age: 2
		},
		{
			first: "First3",
			last: "Last3",
			age: 3
		}
	]);*/

	/*
	enyo.kind({
		name: "Sample.Object",
		kind: "enyo.Object",
		color: "Blue",
		colorChanged: function () {
			this.log();
		},
		_color_changed: enyo.observer(function (property, previous, value) {
			this.log();
		}, "color")
	});

	obj = new Sample.Object();
	obj.addObserver("color", function () {console.log("color")});
	*/

/*
	obj = {
		number: 0
	};

	obj2 = {
		showing: 0
	}*/

	/*
	enyo.kind({

		name: "Sample.Control",
		kind: "enyo.View",
		content: "Yo.",
		events: {
			onMyViewClicked: ""
		},

		handlers: {
			onclick: "ourClickHandler",
			onMyViewClicked: "firstHandler"
		},

		ourClickHandler: function (sender, event) {
			this.doMyViewClicked();
		},

		firstHandler: function (sender, event) {
			return true;
		}

	});

	enyo.kind({
		name: "Sample.OtherView",
		kind: "enyo.View",
		handlers: {
			onMyViewClicked: "clickHandler"
		},
		components: [{
			name: "sampler",
			kind: "Sample.Control"
		}],
		clickHandler: function (sender, event) {
			this.log();
		}
	});

	new Sample.OtherView().renderInto(document.body);
*/

});
